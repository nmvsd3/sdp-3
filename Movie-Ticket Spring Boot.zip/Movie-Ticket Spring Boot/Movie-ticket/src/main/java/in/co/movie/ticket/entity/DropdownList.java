package in.co.movie.ticket.entity;


public interface DropdownList
{
	public String getKey();

	public String getValue();
}
