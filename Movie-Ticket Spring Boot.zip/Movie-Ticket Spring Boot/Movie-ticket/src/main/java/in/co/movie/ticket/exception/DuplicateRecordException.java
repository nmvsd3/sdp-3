package in.co.movie.ticket.exception;


public class DuplicateRecordException  extends Exception
{

	public DuplicateRecordException(String msg) {
		super(msg);
	}
}
